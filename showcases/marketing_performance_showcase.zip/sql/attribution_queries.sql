-- Schema assumptions (DuckDB/Postgres style)
-- Create staging tables
CREATE TABLE stg_web_events (
  event_id INTEGER,
  campaign_id TEXT,
  event_type TEXT,
  event_timestamp TIMESTAMP,
  user_id TEXT
);

CREATE TABLE stg_crm_conversions (
  conversion_id INTEGER,
  user_id TEXT,
  conversion_date DATE,
  conversion_value NUMERIC,
  attributed_campaign_hint TEXT
);

CREATE TABLE stg_marketing_spend (
  date DATE,
  campaign_id TEXT,
  spend NUMERIC
);

-- FIRST TOUCH Attribution (per user -> earliest campaign before conversion)
WITH first_touch AS (
  SELECT
    c.conversion_id,
    c.user_id,
    c.conversion_date,
    c.conversion_value,
    (SELECT we.campaign_id
     FROM stg_web_events we
     WHERE we.user_id = c.user_id
       AND we.event_timestamp::date <= c.conversion_date
     ORDER BY we.event_timestamp ASC
     LIMIT 1) AS first_touch_campaign
  FROM stg_crm_conversions c
),
last_touch AS (
  SELECT
    c.conversion_id,
    c.user_id,
    c.conversion_date,
    c.conversion_value,
    (SELECT we.campaign_id
     FROM stg_web_events we
     WHERE we.user_id = c.user_id
       AND we.event_timestamp::date <= c.conversion_date
     ORDER BY we.event_timestamp DESC
     LIMIT 1) AS last_touch_campaign
  FROM stg_crm_conversions c
)

-- KPI Views
-- 1) Conversions & Revenue by campaign (first touch)
SELECT
  ft.first_touch_campaign AS campaign_id,
  COUNT(*) AS conversions,
  SUM(COALESCE(ft.conversion_value,0)) AS revenue
FROM first_touch ft
GROUP BY 1
ORDER BY conversions DESC;

-- 2) Conversions & Revenue by campaign (last touch)
SELECT
  lt.last_touch_campaign AS campaign_id,
  COUNT(*) AS conversions,
  SUM(COALESCE(lt.conversion_value,0)) AS revenue
FROM last_touch lt
GROUP BY 1
ORDER BY conversions DESC;

-- 3) CAC per campaign (last-touch)
-- Spend joined to conversions by campaign and day
WITH conv_by_day AS (
  SELECT
    lt.last_touch_campaign AS campaign_id,
    lt.conversion_date AS date,
    COUNT(*) AS conversions
  FROM last_touch lt
  GROUP BY 1,2
)
SELECT
  s.campaign_id,
  SUM(s.spend) AS spend,
  SUM(COALESCE(c.conversions,0)) AS conversions,
  CASE WHEN SUM(COALESCE(c.conversions,0))=0 THEN NULL
       ELSE SUM(s.spend) / SUM(c.conversions) END AS cac
FROM stg_marketing_spend s
LEFT JOIN conv_by_day c
  ON c.campaign_id = s.campaign_id
 AND c.date = s.date
GROUP BY 1
ORDER BY cac NULLS LAST;

-- 4) Funnel: click -> landing -> signup -> conversion_request
WITH steps AS (
  SELECT
    campaign_id,
    event_type,
    COUNT(*) AS cnt
  FROM stg_web_events
  WHERE event_type IN ('click','landing','signup','conversion_request')
  GROUP BY 1,2
)
SELECT
  campaign_id,
  MAX(CASE WHEN event_type='click' THEN cnt END) AS clicks,
  MAX(CASE WHEN event_type='landing' THEN cnt END) AS landings,
  MAX(CASE WHEN event_type='signup' THEN cnt END) AS signups,
  MAX(CASE WHEN event_type='conversion_request' THEN cnt END) AS conv_requests
FROM steps
GROUP BY 1
ORDER BY conv_requests DESC NULLS LAST;